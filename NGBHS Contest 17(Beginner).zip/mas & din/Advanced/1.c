#include<stdio.h>
int main(){

int days,month,t,n;
scanf("%d",&t);
for(n=0;n<t;n++){

	scanf("%d",&days);
	month=days/30;
	days=days%30;
	printf ("Case %d: Days: %d Month: %d \n",n+1,days,month);

}
return 0;
}
